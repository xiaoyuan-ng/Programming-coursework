import pygame as pg
import os
from time import *


pg.init()
pg.mixer.init()
pg.mixer.music.load('thelegendofzeldamedly.mp3')
attack_sound = pg.mixer.Sound('attack.wav')
TxtFont = pg.font.Font('Font.ttf', 60)
jump_sound = pg.mixer.Sound('jump.mp3')
click = pg.mixer.Sound('click.mp3')




class Screen:
    def __init__(self, path, caption):
        

        #path: In this case, the path is the path to the location of the background image that we will use for the game. The os module allows us to do this.
        #caption: This is the name of our game that will be displayed on the top of the window
       
       
        pg.display.set_caption(caption)
        #set the name of the screen
         
        self.pic = pg.image.load(path)
        self.screen_width = self.pic.get_rect()[2]
        self.screen_height = self.pic.get_rect()[3]
        #This get rect function returns a list of 4 elements. The first 2 elements are the x and y coordinates of the 
        #background image itself, and the 3rd and 4th are the width and height of the original image. The function
        #is fitting our background image to the window of the screen by creating a rect and fitting it's coordinates

      
    def make_screen(self):
        return pg.display.set_mode((self.screen_width, self.screen_height))
    #Creating the screen
    def choose_Background(self):
        return self.pic
    #Returning the image that will be used as the background


# drawing the screen and the backgroud of the game:
init_screen = Screen('tree.png', 'The brave battle')
# this is the start picture
start_screen = Screen('starting.jpeg', 'The brave battle')
# the developer picture
developer_list = Screen("Developer_list.png", "The brave battle")
# the instruction picture
instruction_screen = Screen("instruction.png", "The brave battle")

# set the screen width and height
screen_width, screen_height = init_screen.screen_width, init_screen.screen_height

option_screen = start_screen.make_screen()
start_screen_backgroud = start_screen.choose_Background()

developer_list_screen = developer_list.make_screen()
developer_list_background = developer_list.choose_Background()

screen = init_screen.make_screen()
Backgroud_picture = init_screen.choose_Background()

instruction_list_screen = instruction_screen.make_screen()
instruction_list_background = instruction_screen.choose_Background()
#These are calling the previosuly defined functions to make backgrounds


# the border
BORDER = 10
# Ground border
Ground_edge = 20
fg_color = pg.Color("blue")
platform_color = pg.Color((209, 162, 8))
platform_list = []
# This list starts as an empty list and then the coordinates of the platforms are added to it to check for collision later

# character attributes
actor_width = 45
actor_height = 75
knife_width = 50
knife_height = 50

"""
Here we are assigning keys to the attack for each character. 
This is using a built in pygame function that returns the state of all keys on the keyboard
"""
a1attack1 = pg.K_f
a1attack2 = pg.K_g
a1attack3 = pg.K_h
a2attack1 = pg.K_i
a2attack2 = pg.K_o
a2attack3 = pg.K_p


# Creating the Character class and initialisng attributes
class Character:
    def __init__(self, actor_name, counting_board_color, actor_width, actor_height, face_right_images, face_left_images, walk_left_images, walk_right_images, left_key, right_key, jump_key, x, y, w, h, stay_frames=3, walk_frames=4, vel=10, vy=-15, standCount=0, walk_count=0, jump=False, face_reverse=False):
        self.actor_width = actor_width
        self.actor_height = actor_height
        self.actor = 'the picture of every frame'
        self.face_right_images = face_right_images
        self.face_left_images = face_left_images
        self.walk_left_images = walk_left_images
        self.walk_right_images = walk_right_images
        # loading all images for this actor
        self.load_images()
        self.stay_frames = stay_frames
        self.walk_frames = walk_frames
        # Definig frames for animation
        self.stand_face_right = True
        self.stand_face_left = False
        self.walk_left = False
        self.walk_right = False
        # To begin with the only one of these set to True initially is facing right as this is the standard starting position
        self.pic_rate_control_face_right = len(
            self.face_right_images) * self.stay_frames
        self.pic_rate_control_face_left = len(
            self.face_left_images) * self.stay_frames
        self.pic_rate_control_left_walk = len(
            self.walk_left_images) * self.walk_frames
        self.pic_rate_control_right_walk = len(
            self.walk_right_images) * self.walk_frames
        """
        The rate control of the images takes the length of the list of images and multiplies it by the stay frames.
        The stay frames are used so that the transition between each animation frame isn't too quick. Multiplying the length 
        of the list by the stay frames will later on let us determine when the animation needs to be switched.
        Could be explained more in the demo part.---- to the TAs and tutors
        """
        self.controller = pg.Rect(x,y,w,h) # Inspiration comes from : https://www.youtube.com/watch?v=jO6qQDNa2UY&t=1s
        # Coordinates of the rectangle of the character
        self.left_key = left_key
        self.right_key = right_key
        self.vel = vel # the horizontal speed
        self.standCount = standCount
        self.walk_count = walk_count
        self.jump = jump
        self.up = jump_key
        self.g = 0.7  # the gravity determining the rate the character falls after jumping
        self.vy = vy # a constant of the start speed of the actor(when the jump is pressed)
        self.vel_y = vy # the distance actors will move for the next flip for the vertical direction.
        self.face_reverse = face_reverse
        self.score = 0
        self.upedge = screen_height - Ground_edge - actor_height
        """
        The upedge is the upside of the edge of the bottom border of the screen. It is made by 
        subtracting the character's height and the whole of the bottom border. This is done to define
        the point of which the character will be standing on, which will be the top of the blue
        border
        """

        self.cooltime = 0 # Cooldown time between frame changes
        self.character_name = actor_name
        self.counting_board_color = counting_board_color

    def actor_scale(self, path):
        return pg.transform.scale(pg.image.load(path), (self.actor_width, self.actor_height))
    # Built in pygame function to scale the image of the character sprite

    def images_list(self, path):
        images = os.listdir(path)
        image_list = []
        for i in images:
            image_list += [path+i]
        return image_list
    # Here we are using the imported OS module. We do this to return a list of files in destination_directory.

    def load_images(self):
        self.face_right_images = self.images_list(self.face_right_images)
        self.face_left_images = self.images_list(self.face_left_images)
        self.walk_left_images = self.images_list(self.walk_left_images)
        self.walk_right_images = self.images_list(self.walk_right_images)
    # Creating the lists of the images for animation
    

    # Inspiration of how to make the actor move comes from: https://www.youtube.com/watch?v=2-DNswzCkqk
    def walk(self):
        self.keys = pg.key.get_pressed()
        if self.keys[self.left_key] and self.controller.x > BORDER:
            self.controller.x -= self.vel
            self.stand_face_right = False
            self.stand_face_left = False
            self.walk_left = True
            self.walk_right = False
            self.face_reverse = True

        elif self.keys[self.right_key] and self.controller.x+actor_width+self.vel < screen_width-BORDER:
            self.controller.x += self.vel
            self.stand_face_right = False
            self.stand_face_left = False
            self.walk_left = False
            self.walk_right = True
            self.face_reverse = False

        elif self.face_reverse:
            self.stand_face_right = False
            self.stand_face_left = True
            self.walk_left = False
            self.walk_right = False
            self.walk_count = 0

        else:
            self.stand_face_right = True
            self.stand_face_left = False
            self.walk_left = False
            self.walk_right = False
            self.face_reverse = False
            self.walk_count = 0
        """
        These are using the pygame built in functions for key presses. We use simple booleans in order to set
        the action we want to happen for the key press to be true and the rest to false.
        """


        if self.stand_face_right:
            if self.standCount < self.pic_rate_control_face_right:
                self.actor = self.actor_scale(
                    self.face_right_images[self.standCount // self.stay_frames])
                self.standCount += 1
            else:
                self.standCount = 0

        """
        Here we add 1 to the standCount for each element of the list of images
        We keep doing this until the standcount exceeds the pic rate control.
        This is done to ensure that the stay frames aren't switched until each image is held for a while.
        """

        if self.stand_face_left:
            if self.standCount < self.pic_rate_control_face_left:
                self.actor = self.actor_scale(
                    self.face_left_images[self.standCount // self.stay_frames])
                self.standCount += 1
            else:
                self.standCount = 0
        if self.walk_left:
            if self.walk_count < self.pic_rate_control_left_walk:
                self.actor = self.actor_scale(
                    self.walk_left_images[self.walk_count//self.walk_frames])
                self.walk_count += 1
            else:
                self.walk_count = 0
        if self.walk_right:
            if self.walk_count < self.pic_rate_control_right_walk:
                self.actor = self.actor_scale(
                    self.walk_right_images[self.walk_count // self.walk_frames])
                self.walk_count += 1
            else:
                self.walk_count = 0

    def Jump(self): # Insprition comes from https://www.youtube.com/watch?v=2-DNswzCkqk
        self.keys = pg.key.get_pressed()
        if not self.jump:  
            if self.keys[self.up]:
                self.jump = True
                self.vel_y = self.vy
                jump_sound.play()
        # Using pygame built in function to play the sound when the character jumps.
        elif self.controller.y + self.vel_y < self.upedge:
            self.vel_y += self.g
            self.controller.y += self.vel_y
            """
            Adding the velocity to the gravity for the jump if the y coordinate of the character
            added to the velocity of y is higher than the position of the top of the border of the edge
            """
        else:
            # make the actor felling to exactly the right y coordinate
            self.vel_y = self.upedge - self.controller.y # Insprition comes from: https://www.youtube.com/watch?v=WvcNfwIl2Jw
            self.controller.y += self.vel_y

            if self.keys[self.up]:
                self.jump = False
            else:
                self.jump = True
            """
            This is stopping you from jumping if the character is not on the platforms/ground.
            When the jump is set to true, the beginning clocks of jump will never be active, the vel_y will be set 
            into 0, that means the characters can never jump again.
            """

    def action(self, platform_list):
        self.counting_board = TxtFont.render(f'{self.character_name}: {self.score}', False, self.counting_board_color)
        self.walk()
        self.Jump()
        self.upedge = screen_height - Ground_edge - actor_height
        self.rect = self.actor.get_rect()
        self.rect.x = self.controller.x
        self.rect.y = self.controller.y
        self.collide(platform_list)
        

    def collide(self, platform_list):
        for i in platform_list:
            temp_rect = pg.Rect(i[0], i[1]-actor_height, i[2], i[3])
            if self.rect.colliderect(temp_rect) and self.vel_y > 0:
                self.upedge = i[1]-actor_height
    """
    This collision function creates a temporary rectangle of the platform 
    It then uses the built in pygame function to check if this temporary rectangke is colliding with
    the character rectangle. If it does, and if the character is moving down, then it re defines the upside edge to be the bottom 
    of the character's height in order to allow us to set each one of our created platforms
    to be able to be stood on by the character.
    """


# Creating the throwing knife class and initialising it's attributes
class Knife:

    def __init__(self, knife_width, knife_height, hold_images,  attack_key1, attcak_key2, attack_key3, selfact, enemy, x, y, w, h):
        self.knife_width = knife_width
        self.knife_height = knife_height
        self.knife = 0
        self.hold_images = hold_images
        self.load_images()
        self.knifeCount = 0
        self.attack_key1 = attack_key1
        self.attack_key2 = attcak_key2
        self.attack_key3 = attack_key3
        self.time = 0
        self.selfact = selfact # means the character who hold the weapon
        self.enemy = enemy
        self.thrown = False 
        self.hold_frames = 3
        self.pic_rate_control_knife = len(
            self.hold_images) * self.hold_frames
        self.controller = pg.Rect(x,y,w,h)
        
    def knife_scale(self, path):
        return pg.transform.scale(pg.image.load(path), (self.knife_width, self.knife_height))
    # loading the knife image and scaling it using the built in pygame function

    def images_list(self, path):
        images = os.listdir(path)
        image_list = []
        for i in images:
            image_list += [path + i]
        return image_list
    # same as the characters

    def load_images(self):
        self.hold_images = self.images_list(self.hold_images)
    
    # Creating list of the images


    def hold(self):

        if not self.thrown:
            if self.knifeCount < self.pic_rate_control_knife:
                self.knife = self.knife_scale(
                    self.hold_images[self.knifeCount // self.hold_frames])
                self.knifeCount += 1
            else:
                self.knifeCount = 0
            
            # Same as the previous function which controls the characters animation
            if self.selfact.stand_face_right or self.selfact.walk_right:
                self.controller.x = self.selfact.controller.x + 15
                self.controller.y = self.selfact.controller.y + 10
            elif self.selfact.stand_face_left or self.selfact.walk_left:
                self.controller.x = self.selfact.controller.x - 15
                self.controller.y = self.selfact.controller.y + 10

    def action(self):
        self.hold()
        self.attack()
        self.rect = self.knife.get_rect()
        self.rect.x = self.controller.x
        self.rect.y = self.controller.y
        if time() - self.time >1.5:
            self.thrown = False
        """
        Here we are not letting a knife be thrown unless 1.5 seconds has been passed so that you cannot
        constantly throw knives
        """
        
        self.getpoints()  # Only after the knife is thrown and it collide with the enemy then characters can get points
        
    def attack(self):
        self.keys = pg.key.get_pressed()
        if not self.thrown:
            if self.selfact.stand_face_right or self.selfact.walk_right:
                a = 1
            else:
                a = -1
            if self.keys[self.attack_key1]:
                self.thrown = True
                self.time = time()
                self.vel_x = 20*a
                self.vel_y = 0
            elif self.keys[self.attack_key2]:
                self.thrown = True
                self.time = time()
                self.vel_x = 17.3*a
                self.vel_y = 10
            elif self.keys[self.attack_key3]:
                self.thrown = True
                self.time = time()
                self.vel_x = 10*a
                self.vel_y = 17.3
            """
            Defining the angles of throw for each different attack press. First is directly horizontal,
            then is 30 degrees and then is 60 degrees upwards. 
            If you are interested in how an angle is calculated, we can explain in demo.
            """
                
        else:
            self.controller.x += self.vel_x
            self.controller.y -= self.vel_y
            # The knife has been thrown so set the velocity for the knife to the controller.

    def getpoints(self):
        if self.controller.colliderect(self.enemy.controller) and (time() - self.selfact.cooltime) > 3 and self.thrown:
            self.selfact.cooltime = time()
            self.selfact.score += 1
            attack_sound.play()
        """
        Adding 1 to the score when a player is hit by the knife, but only if
        3 seconds has passed after the last hit
        """



# Create actor1
actor1 = Character("Skeleton", (255, 107, 100), actor_width, actor_height, 'skeleton/StandR/', 'skeleton/StandL/',
               'skeleton/WalkingLeft/', 'skeleton/WalkingRight/', pg.K_a, pg.K_d, pg.K_w, BORDER, screen_height - Ground_edge - actor_height, actor_width, actor_height)
actor2 = Character("Hero", (255, 255, 255), actor_width, actor_height, 'Hero/StandR/', 'Hero/StandL/', 'Hero/WalkingLeft/',
               'Hero/WalkingRight/', pg.K_LEFT, pg.K_RIGHT, pg.K_UP, screen_width - BORDER - actor_width, screen_height - Ground_edge - actor_height, actor_width, actor_height)
knife1 = Knife(knife_width, knife_height, 'Knife/hold/', a1attack1,a1attack2,a1attack3, actor1,actor2,BORDER+actor_width, screen_height - Ground_edge - 0.5*actor_height, knife_width, knife_height)
knife2 = Knife(knife_width, knife_height, 'Knife/hold/', a2attack1,a2attack2,a2attack3, actor2,actor1,screen_width-BORDER-actor_width-actor_width, screen_height - Ground_edge - 0.5*actor_height, knife_width, knife_height)
# the FPS of this game
FPS = 60
clock = pg.time.Clock()


# tCreating the platform class
class Pf():

    def __init__(self, x, y, PFW=screen_width//5, PFH=10):
        self.x = x
        self.y = y
        self.PFW = PFW
        self.PFH = PFH

    def show(self):
        global screen
        global platform_color
        global platform_list
        p1 = pg.Rect(self.x, self.y, self.PFW, self.PFH)
        p2 = pg.Rect(screen_width-self.x-self.PFW, self.y, self.PFW, self.PFH)
        pg.draw.rect(screen, platform_color, p1)
        pg.draw.rect(screen, platform_color, p2)
        if [self.x, self.y, self.PFW, self.PFH] in platform_list:
            pass
        else:
            platform_list += [[self.x, self.y, self.PFW, self.PFH],
                              [screen_width-self.x-self.PFW, self.y, self.PFW, self.PFH]]


#
edges = [pg.Rect(0, 0, screen_width, BORDER),
         pg.Rect(0, screen_height - Ground_edge, screen_width, Ground_edge),
         pg.Rect(0, 0, BORDER, screen_height),
         pg.Rect(screen_width - BORDER, 0, BORDER, screen_height)
         ]


class Label:

    def __init__(self, des_surface, x, y, font, text_size, text, text_color):
        self.des_surface = des_surface #
        self.x = x
        self.y = y
        self.text_surface = pg.font.Font(font, text_size).render(text, False, text_color)

    def show(self):
        text_rect = self.text_surface.get_rect()
        text_rect.center = (self.x, self.y)
        self.des_surface.blit(self.text_surface, text_rect)
    """
    This class is being used to draw on the screen using built in pygame functions
    of fonts and then the blit functions to put them on the screen
    """


class Button(Label):

    def __init__(self, des_surface, x, y, font, text_size, text, text_color):
        super().__init__(des_surface, x, y, font, text_size, text, text_color)
        self.text_surface.get_rect()
        self.width = self.text_surface.get_width()
        self.height = self.text_surface.get_height()
        self.status = False

    def trigger(self):
        self.mouse_x, self.mouse_y = pg.mouse.get_pos()
        if self.x - self.width//2 <= self.mouse_x <= self.x + self.width//2 and self.y - self.height//2 <= self.mouse_y <= self.y + self.height//2:
            if pg.mouse.get_pressed()[0]:
                self.status = True
                click.play()
                pg.mixer.music.play(loops=-1)
        # This enables clicking onto the destination of the created surface. We have assigned it to a left click.

def main():
    run = True
    start_interface = True
    developer = False
    instructions_show = False

    while run:
        clock.tick(FPS)
        for event in pg.event.get():
            if event.type == pg.QUIT:
                run = False
        if start_interface:
            option_screen.blit(start_screen_backgroud, (0, 0))
            start = Button(option_screen, screen_width//2, screen_height//2 - 50, 'Font.ttf', 30, 'Start', "red")
            Developer_list = Button(option_screen, screen_width//2, screen_height//1.5 - 50, 'Font.ttf', 30, 'Developer list', "red")
            instructions = Button(option_screen, screen_width//2, screen_height//1.2 - 50, 'Font.ttf', 30, 'Instructions', "red")
            start.show()
            start.trigger()
            Developer_list.show()
            Developer_list.trigger()
            instructions.show()
            instructions.trigger()
            if start.status:
                start_interface = False

            elif Developer_list.status:
                start_interface = False
                developer = True

            elif instructions.status:
                start_interface = False
                instructions_show = True

            pg.display.flip()

        elif developer:
            developer_list_screen.blit(developer_list_background,(0,0))
            back = Button(developer_list_screen, screen_width - 100, screen_height - 100, 'Font.ttf', 30, 'Back',
                           "red")
            back.show()
            back.trigger()
            if back.status:
                start_interface = True
                developer = False
                instructions_show = False
            pg.display.flip()

        elif instructions_show:
            instruction_list_screen.blit(instruction_list_background, (0, 0))
            back_instuction = Button(instruction_list_screen, screen_width - 100, screen_height - 80, 'Font.ttf', 30, 'Back',
                          "red")
            back_instuction.show()
            back_instuction.trigger()
            if back_instuction.status:
                start_interface = True
                developer = False
                instructions_show = False
            pg.display.flip()
        else:
            # draw the background
            screen.blit(Backgroud_picture, (0, 0))
            # drawing the edge of the border
            # Top side
            for i in edges:
                pg.draw.rect(screen, fg_color, i)

            # drawing the platforms(in pair to ensure the equity)
            # Top side
            Pf(screen_width // 8, screen_height // 6).show()  # The highest group
            Pf(BORDER, screen_height // 3).show()  # second highest group
            # the board players StandR on.
            Pf(screen_width // 10, screen_height // 2).show()
            Pf(screen_width // 6, screen_height -
               screen_height // 3).show()  # lowest board
            Pf(screen_width // 2 - screen_width // 8,
               screen_height // 3.5).show()  # middle board



            actor1.action(platform_list)
            actor2.action(platform_list)
            knife1.action()
            knife2.action()


            screen.blit(actor1.actor, (actor1.controller.x, actor1.controller.y))
            # pg.draw.rect(screen, (255, 255, 255), actor1.rect, 1)
            screen.blit(actor2.actor, (actor2.controller.x, actor2.controller.y))
            # pg.draw.rect(screen, (255, 255, 255), actor2.rect, 1)
            screen.blit(knife1.knife, (knife1.controller.x, knife1.controller.y))
            # pg.draw.rect(screen, (255, 255, 255), knife1.rect, 1)
            screen.blit(knife2.knife, (knife2.controller.x, knife2.controller.y))
            # pg.draw.rect(screen, (255, 255, 255), knife2.rect, 1)
            """
            If you want to see the rect.controller, you can enable this code.
            """

            screen.blit(actor1.counting_board, (30, 30))
            screen.blit(actor2.counting_board, (screen_width - 215, 30))
            if actor1.score == 5 or actor2.score == 5:
                if actor1.score == 5:
                    winner = actor1.character_name
                else:
                    winner = actor2.character_name
                ending_paddle = Label(screen, screen_width//2, screen_height//2, 'Font.ttf', 100, f'{winner} wins!', "black")
                ending_paddle.show()
                restart = Button(screen, screen_width//2, screen_height//2 + 100, 'Font.ttf', 30, "Restart", "black")
                restart.show()
                restart.trigger()
                back_to_menu = Button(screen, screen_width//2, screen_height//2 + 200, 'Font.ttf', 30, "Back to menu", "black")
                back_to_menu.show()
                back_to_menu.trigger()
                if back_to_menu.status:
                    back_to_menu.status = False
                    start_interface = True
                    actor1.score, actor1.controller.x,actor1.controller.y, actor1.cooltime, actor1.stand_face_right, actor1.stand_face_left, actor1.walk_left, actor1.walk_right, actor1.jump, actor1.face_reverse = 0,BORDER, screen_height - Ground_edge - actor_height, 0, True, False, False, False, False, False
                    actor2.score, actor2.controller.x, actor2.controller.y, actor2.cooltime, actor2.stand_face_right, actor2.stand_face_left, actor2.walk_left, actor2.walk_right, actor2.jump, actor2.face_reverse = 0, screen_width - BORDER - actor_width, screen_height - Ground_edge - actor_height, 0, True, False, False, False, False, True
                    """
                    Set the parameters of all characters to the default settings when you click back_to_menu.
                    """

                if restart.status:
                    restart.status = False
                    actor1.score, actor1.controller.x,actor1.controller.y, actor1.cooltime, actor1.stand_face_right, actor1.stand_face_left, actor1.walk_left, actor1.walk_right, actor1.jump, actor1.face_reverse = 0,BORDER, screen_height - Ground_edge - actor_height, 0, True, False, False, False, False, False
                    actor2.score, actor2.controller.x, actor2.controller.y, actor2.cooltime, actor2.stand_face_right, actor2.stand_face_left, actor2.walk_left, actor2.walk_right, actor2.jump, actor2.face_reverse = 0, screen_width - BORDER - actor_width, screen_height - Ground_edge - actor_height, 0, True, False, False, False, False, True

            pg.display.flip()


    pg.quit()


if __name__ == '__main__':
    main()
